#!/bin/bash
apt-get update
apt-get upgrade -y
apt install python-pip -y
apt install python3-pip -y
apt-get install cacti
apt-get install smokeping -y
# Commands above are what install the directories needed to complete the following commands below
cd /smokeping/
cp  /smokeping/ports.conf /etc/apache2/ports.conf
cp  /smokeping/pathnames /etc/smokeping/config.d/pathnames
cp  /smokeping/Probes /etc/smokeping/config.d/Probes
cp  /smokeping/serve-cgi-bin.conf /etc/apache2/conf-available/serve-cgi-bin.conf
cp  /smokeping/Targets /etc/smokeping/config.d/Targets
cp /smokeping/General /etc/smokeping/config.d/General
grep -oE -m 1 "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" /etc/dhcpcd.conf
grep -oE -m 2 "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" /etc/dhcpcd.conf | tail -n1
grep -oE -m 1 "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" /etc/network/interfaces
grep -oE -m 3 "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" /etc/network/interfaces | tail -n1
(sed 's/.*remote \(.*\)1194/\1/' /etc/openvpn/opie.conf | grep talkrx)
SKYADDR="$(sed 's/.*remote \(.*\)1194/\1/' /etc/openvpn/opie.conf | grep talkrx)"
IPADDR="$(grep -oE -m 1 "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" /etc/dhcpcd.conf)"
IPADDR="$(grep -oE -m 1 "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" /etc/network/interfaces)"
GATEWAY="$(grep -oE -m 2 "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" /etc/dhcpcd.conf | tail -n1)"
GATEWAY="$(grep -oE -m 3 "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" /etc/network/interfaces | tail -n1)"
sed -i -e "s/IPADDR/$IPADDR/g" /etc/smokeping/config.d/General
sed -i -e "s/GATEWAY/$GATEWAY/g" /etc/smokeping/config.d/Targets
sed -i -e "s/SKYADDR/$SKYADDR/g" /etc/smokeping/config.d/Targets
# Commands with cp use the directory "smokeping" to copy the correct files with the correct info into the correct paths
service smokeping start
# General needs user input to put in the Opies IP address (Hopefully can be automated at some point)
a2enmod cgi
service apache2 restart
service smokeping restart
# Needs user input, needs default gateway and talkrx sky address (Hopefully can be automated)
rm /var/lib/smokeping/Local/LocalMachine.rrd
pip install -U tzupdate
tzupdate
service smokeping restart
# The commands above are essential for smokeping to run and cannot be altered. Need to always be at the very end.